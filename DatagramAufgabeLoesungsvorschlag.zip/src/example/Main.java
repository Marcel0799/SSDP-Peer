package example;

import java.net.DatagramPacket;
import java.util.LinkedList;
import java.util.concurrent.Semaphore;

/**
 * 
 * Hauptklasse für das Program. Erzeugt und startet die beiden Threads.
 * Zusätzlich wird das Erzeugen der Beispieldaten angestoßen. <br />
 * <br />
 * Hält zusätzlich die Liste der empfangenen Pakete vor.
 */
public class Main {
	/**
	 * Liste die als Warteschlange fungiert. Hier sollen die empfangenen Pakete
	 * landen.
	 */
	public static LinkedList<DatagramPacket> queue = new LinkedList<>();
	/**
	 * Semaphore, die den Zugriff auf die queue regelt. Sollte immer die gleiche
	 * Anzahl an <i>permits</i> wie die queue haben.
	 */
	public static Semaphore semQueue = new Semaphore(0);

	/**
	 * Die Main-Funktion. Tut das, was in der Klassenbeschreibung steht.
	 * 
	 * @param args <i>ignoriert</i>
	 */
	public static void main(String[] args) {
		System.out.println();
		WorkerA wa = new WorkerA();
		WorkerB wb = new WorkerB();
		Thread a = new Thread(wa);
		Thread b = new Thread(wb);
		a.start();
		b.start();
		TestDataGen tdg = new TestDataGen();
		tdg.loop();
	}

	public static void done() {
		queue = null;
		semQueue.release();
	}

}
