package example;

import java.io.IOException;
import java.net.*;

public class WorkerA implements Runnable {
	public DatagramSocket ds;

	public WorkerA() {
		try {
			// TODO: DatagramSocket initialisieren
			ds = new DatagramSocket(9081); //-- Neues DatagramSocket erstellen und an den Port binden
		} catch (SocketException e) {
			// Fehlerbehandlung
			e.printStackTrace();
		}
	}

	/**
	 * Methode, die der Thread ausführt. <br />
	 * Hier soll nur der Puffer erzeugt, ein Paket empfangen und dann weitergegeben
	 * werden. <br />
	 * Dies soll solange passieren, wie das DatagramSocket nicht null, gebunden und
	 * nicht geschlossen ist.
	 */
	@Override
	public void run() {
		while (ds != null && ds.isBound() && !ds.isClosed()) {
			try {
				// TODO: Hier Puffer erstellen, Paket empfangen und in die Queue einreihen.
				DatagramPacket buffer = createBuffer();
				ds.receive(buffer);
				queuePacket(buffer);
				
			} catch (SocketException sexc) {
				// Fehlerbehandlung
				sexc.printStackTrace();
			} catch (IOException ioexc) {
				// Fehlerbehandlung
				ioexc.printStackTrace();
			}
		}
	}
	/**
	 * Erzeugt einen neuen Puffer.
	 */
	public DatagramPacket createBuffer() throws SocketException {
		return new DatagramPacket(new byte[ds.getReceiveBufferSize()], ds.getReceiveBufferSize());
	}
	/**
	 * Reiht ein Paket in die Queue ein und benachrichtigt WorkerB
	 * @param dp Das einzureihende Paket.
	 */
	public void queuePacket(DatagramPacket dp) {
		if (Main.queue == null) {
			ds.close();
			return;
		}
		synchronized(Main.queue)
		{
            Main.queue.add(dp);
		}
		Main.semQueue.release();
	}
}
