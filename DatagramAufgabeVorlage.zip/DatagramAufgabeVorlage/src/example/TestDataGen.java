package example;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
/**
 * Hier werden die Test-Daten generiert.
 */
public class TestDataGen {
	private ArrayList<Integer> ints = new ArrayList<>();
	private DatagramSocket ds;

	public TestDataGen() {
		try {
			ds = new DatagramSocket(9082);
		} catch (SocketException e) {
			// Fehlerbehandlung
			e.printStackTrace();
		}
		Random r = new Random();
		int start = r.nextInt(32768) + 32768;
		System.out.println(start);
		for (int i = 0; i < 10; i++)
			ints.add(start + i);
		Collections.shuffle(ints);

	}

	public void loop() {
		try {
			for (Integer i : ints) {
				ByteBuffer bb = ByteBuffer.allocate(4);
				bb.putInt(i);
				System.out.println("Versende " + i);
				bb.flip();
				DatagramPacket dp = new DatagramPacket(bb.array(), 0, 4, InetAddress.getLocalHost(), 9081);
				ds.send(dp);
				Thread.sleep(100);
			}
			Main.done();
			for(int i = 0;i<10;i++)
			{
				DatagramPacket dp = new DatagramPacket( new byte[]{0,0,0,0}, 0, 4, InetAddress.getLocalHost(), 9081);
				ds.send(dp);
			}
		} catch (Exception exc) {
			// ignore
		}
		Main.done();
	}
}
