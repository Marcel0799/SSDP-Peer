package example;

import java.net.DatagramPacket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
/**
 * In dieser Klasse sollen die Pakete (von WorkerA) abgearbeitet werden.
 */
public class WorkerB implements Runnable {
	private ArrayList<Integer> ints = new ArrayList<>();
	@Override
	public void run() {
		while (true) {
			// Auf neues Paket warten
			Main.semQueue.acquireUninterruptibly();
			// Falls die queue nicht mehr existiert, Schleife unterbrechen;
			if (Main.queue == null)
				break;
			/* TODO: Nächstes Paket abarbeiten
			 * - also der Queue entnehmen (siehe Main.queue.pop()), Daten extrahieren und
			 * an die Liste anhängen.
			 */
			//-- 
			//-- 
			//-- 
		}
		// TODO: Liste (der Paket-Werte, "ints") sortieren
		//-- 
		System.out.println(ints.toString());
	}

	/**
	 * Extrahiert die Daten aus einem Paket
	 * @param dp das Paket
	 * @return die extrahierten Daten
	 */
	public static int extractData(DatagramPacket dp) {
		System.out.print("Extrahiere Daten: ");
		/* Binär-Daten in einen Puffer lesen (wie ByteBuffer funktionieren ist an dieser Stelle irrelevent)
		 * ByteBuffer vereinfachen es binärkodierte Integer wieder zurück zu konvertieren.
		 */
		ByteBuffer buffer = ByteBuffer.allocate(dp.getData().length);
		buffer.put(dp.getData());
		buffer.flip();
		// Integer aus Bytes bestimmen
		int value = buffer.getInt();
		System.out.println(value);
		if(value == 0) Main.done();
		// Falls text:
		// String value = new String(buffer,start,länge);
		return value;
	}
}
